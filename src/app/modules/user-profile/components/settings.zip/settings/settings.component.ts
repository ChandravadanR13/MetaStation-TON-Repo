import { Component } from '@angular/core';
import { NgOtpInputConfig } from 'ng-otp-input';
import { ProfileService } from 'src/app/Services/profile.service';
import { IntermediateService } from 'src/app/Services/intermediate.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

// Custom Validator Function

export const atLeastOneRequired: ValidatorFn = (
  control: FormGroup
): ValidationErrors | null => {
  const controls = Object.keys(control.controls);

  const isAtLeastOneFieldPopulated = controls.some((controlName: string) => {
    const controlValue = control.get(controlName)?.value;
    return (
      controlValue !== null && controlValue !== '' && controlValue !== undefined
    );
  });

  return isAtLeastOneFieldPopulated ? null : { atLeastOneRequired: true };
};

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent {
  section = 0;
  tele: any[] = [];
  emaillist:any[] =[];
  noti = 0;
  whats: any[] = [];
  smslist: any[] =[];
  dis: any[] = [];
  activeIndex = 1;
  modal: any;
  modal2:any;
  public error = '';
  public isShown:boolean =false;
  public isDisabled:boolean =false;
  isError ='';

  type:any;
  telegram:string='telegram';
  discord:string='discord';
  whatsapp:string='whatsapp';
  email:string='email';
  sms:string='sms';
  resetprofileForm!: FormGroup;

  profileForm ={
    twofaStatus:'',
    twofaType:'',
    phoneNumber:'',
    googleSecret:'',
    email:'',
    google2faVerify:'',
    qrCode:''
  };
  
  twoFaForm ={
    twofa:'',
    OTP:'',    
  }

  config :NgOtpInputConfig = {
    allowNumbersOnly: true,
    length: 6,
    isPasswordInput: false,
    disableAutoFocus: false,
    placeholder: ''
  };

  resetForm = {
    email: '',
    otp: '',
  };

    atLeastOneRequired: ValidatorFn = (
    control: FormGroup
  ): ValidationErrors | null => {
    const controls = Object.keys(control.controls);

    const isAtLeastOneFieldPopulated = controls.some((controlName: string) => {
      const controlValue = control.get(controlName)?.value;
      return (
        controlValue !== null &&
        controlValue !== '' &&
        controlValue !== undefined
      );
    });

    return isAtLeastOneFieldPopulated ? null : { atLeastOneRequired: true };
  };


  constructor( private profile:ProfileService, 
     private myservice: IntermediateService,
     private fb: FormBuilder) {}

  ngOnInit() {

    this.profile. profiledetails().subscribe(
      data => this.handleUserProfile(data),
      error => this.handleError(error)
    );
     
     
    this.modal = document.getElementById("myModal");
    this.modal2 = document.getElementById("myModal2");

    this.resetprofileForm = this.fb.group(
      {
        name: [''],
        email: ['', Validators.email],
        phone_number: [''],
      },
      { validators: this.atLeastOneRequired }
    );

    this.emaillist = [
      {
        label: 'Personal Notification' ,code:'PN'
      },
      {
        label: 'Login alerts for new device',code:'LA'
      },
      {
        label: 'Signal message alerts',code:'SM'
      },
      {
        label: 'Executed trades alerts',code:'ET'
      },
      {
        label: 'Inbox message alerts',code:'IM'
      },
      {
        label: 'Security alerts',code:'SA'
      },
      {
        label: 'Promotional Discount alerts',code:'PD'
      },
    ];
    this.tele = [
      {
        label: 'Personal Notification' ,code:'PN'
      },
      {
        label: 'Login alerts for new device',code:'LA'
      },
      {
        label: 'Signal message alerts',code:'SM'
      },
      {
        label: 'Executed trades alerts',code:'ET'
      },
      {
        label: 'Inbox message alerts',code:'IM'
      },
      {
        label: 'Security alerts',code:'SA'
      },
      {
        label: 'Promotional Discount alerts',code:'PD'
      },
    ];

    this.dis = [{
      label: 'Personal Notification',code:'PN'
    },
    {
      label: 'Login alerts for new device',code:'LA'
    },
    {
      label: 'Signal message alerts',code:'SM'
    },
    {
      label: 'Executed trades alerts',code:'ET'
    },];

    this.whats = [{
      label: 'Signal message alerts',code:'SM'
    },
    {
      label: 'Executed trades alerts',code:'ET'
    },
    {
      label: 'Inbox message alerts',code:'IM'
    },
    {
      label: 'Security alerts',code:'SA'
    },
    {
      label: 'Promotional Discount alerts',code:'PD'
    },];

    this.smslist = [{
      label: 'Blog Posts',code:'BP'
    },
    {
      label: 'Security alerts',code:'SA'
    },
    {
      label: 'Promotional Discount alerts',code:'PD'
    },];
  }

  notifiClick(item:any,name:string){
    console.log(item.code,item.checked,name);
    
    const data = {
      label: item.code,
      type: name,
      action: item.checked,
     };

    return this.profile.updateNotification(data).subscribe(
      data=> console.log(data),
      error => this.handleError(error)
    );      
  }

  handleUserProfile(data:any){
    if(data.success){
      this.profileForm.twofaStatus      = data.result.twofa_status ? data.result.twofa_status : '';
      this.profileForm.twofaType        = data.result.twofa  ? data.result.twofa :'';
      this.profileForm.googleSecret     = data.result.googlesecret ? data.result.googlesecret:'';
      this.profileForm.google2faVerify  = data.result.google2fa_verify ? data.result.google2fa_verify:'';
      this.profileForm.email            = data.result.email ? data.result.email:'',
      this.profileForm.phoneNumber      = data.result.phonenumber ? data.result.phonenumber:'';
      this.profileForm.qrCode           =  data.result.googleqrimage ? data.result.googleqrimage:'';
      
      const twofastatus = this.profileForm.twofaStatus;
      console.log('sdgfusdfsdf:',twofastatus);

      if(twofastatus == '1' ){

        this.isDisabled = true;
        this.type =this.profileForm.twofaType;
     }
     else{
      this.isDisabled = false;
      console.log(this.isDisabled);
     }

    }
  }

  twoFaSubmit(){
    console.log('asdasd',this.twoFaForm);
    console.log(this.profileForm)
    const type =this.twoFaForm.twofa
    const number =this.profileForm.phoneNumber;
    const QrCode =this.profileForm.qrCode;
    console.log('qqqq:',QrCode);

    if(type === 'mobile'){
        if(number !== '' && number !== undefined){
          this.activeIndex =1;
          this.openModel();
          return this.myservice.enabletwofa(this.twoFaForm).subscribe(
            data=> console.log(data),
            error => this.handleError(error)
          );
        }
        else{
          this.error = 'Please Update Your Mobile Number ';
        }
    }
    else if(type == 'google'){
        if( QrCode !== ''){
           this.isShown = true;
           this.openModel2();
           return this.myservice.enabletwofa(this.twoFaForm).subscribe(
            data=> console.log(data),
            error => this.handleError(error)
          );
        }
        else {
           this.isShown =false;
           this.openModel2();
        } 
    }
    else if(type == 'none'){
        return this.myservice.disabletwofa(this.twoFaForm).subscribe(
          (data:any)=>{
            if(data.success){
              this.activeIndex = 2;
              this.openModel();
              this.isDisabled = false;
              this.type ='';
            }
          },
          (error)=>{
            this.handleError(error)
          }
        ) 
    }
    return null
  }

  twoFaotp(){
    console.log(this.twoFaForm)
    const type =this.twoFaForm.twofa
    if(type !== ''){
        return this.myservice.verifyTwofa(this.twoFaForm).subscribe(
          data=> this.handlegoogleVerifyRes(data),
          error => this.handleError(error)
        );
    }
    else{
      this.error ='Some thing Went Wrong'
    }
    return  
  }

  handlegoogleVerifyRes(data:any){
    console.log('v');
    if(data.success){
      this.activeIndex = 2;
      this.openModel();
      this.isDisabled = true;
      console.log(this.twoFaForm.twofa);
      if(this.twoFaForm.twofa == 'mobile'){
          this.type ='email_otp'
      }
      else if(this.twoFaForm.twofa == 'google'){
        this.type = 'google_otp'
      }
      console.log('yesss',this.type);
    }
    else{
      this.error = data.message
    }
  }




  handleError(error:any){
    console.log(error);
  }
  changeNoti(num: number) {
    this.noti = num;
  }
  //  Modal 2 
  openModel() {
    this.modal.style.display = "block";
  }
   closeModel() {
    this.modal.style.display = "none";
   }
  //  Modal 2 
   openModel2() {
    this.modal2.style.display = "block";
  }
  closeModel2() {
    this.modal2.style.display = "none";
   }
   //  Modal 1 loop 
   submit(){
    if(this.activeIndex < 2) {
      this.activeIndex++;
    }
   }

   submitForm() {
    const name = this.resetprofileForm.value.name;
    const email = this.resetprofileForm.value.email;
    const phone_no = this.resetprofileForm.value.phone_number;

    if (phone_no != '' && phone_no !== null) {
      this.openModel();
      return this.profile.resetProfile(this.resetprofileForm.value).subscribe(
        (data) => this.handleresetsuccess(data),
        (error) => this.handleError(error)
      );
    } else if (email != '' && email !== null) {
      return this.profile.resetProfile(this.resetprofileForm.value).subscribe(
        (data) => this.handleresetsuccess(data),
        (error) => this.handleError(error)
      );
    } else {
      this.profile.resetProfile(this.resetprofileForm.value).subscribe(
        (data) => {
          this.profile.setUsername(name);
          this.resetprofileForm.reset()},
        (error) => this.handleError(error)
      );
    }
    return null;
  }

  handleresetsuccess(data: any) {
    if (data.success) {
      this.openModel();
      this.resetprofileForm.reset();
    } else {
      this.isError = data.message;
    }
  }



  // getFinalKey() {
  //    // get final key
  // let otp_inputs = document.querySelectorAll(".otp__digit");
  // var mykey = "0123456789".split("");
  // otp_inputs.forEach((_) => {
  //   _.addEventListener("keyup", handle_next_input);
  // });
  // var two_otp_inputs = document.querySelectorAll(".two_otp__digit");
  // var mykey = "0123456789".split("");
  // two_otp_inputs.forEach((_) => {
  //   _.addEventListener("keyup", handle_next_input);
  // });
  // var two_otp_inputs = document.querySelectorAll(".auth_otp__digit");
  // var mykey = "0123456789".split("");
  // two_otp_inputs.forEach((_) => {
  //   _.addEventListener("keyup", handle_next_input);
  // });
  // function handle_next_input(event: any) {
  //   let current = event.target;
  //   let index = parseInt(current.classList[1].split("__")[2]);
  //   current.value = event.key;

  //   if (event.keyCode == 8 && index > 1) {
  //     current.previousElementSibling.focus();
  //   }
  //   if (index < 6 && mykey.indexOf("" + event.key + "") != -1) {
  //     var next = current.nextElementSibling;
  //     next.focus();
  //   }
  //   var _finalKey = "";
  //   otp_inputs.forEach( ele => {
  //     _finalKey += ele;
  //   })
  //   if (_finalKey.length == 6) {
  //     let otp = document.querySelector("#_otp") as HTMLElement;
  //     otp.innerText = _finalKey;
  //   } else {
  //     let otp = document.querySelector("#_otp") as HTMLElement;
  //     otp.innerText = _finalKey;
  //   }
  // }
  // }


  // openTab(evt: any, cityName : string) {
  //   var i, tablinks;
  //   let tabcontent = document.getElementsByClassName("tabcontent");
  //   for (i = 0; i < tabcontent.length; i++) {
  //     tabcontent[i].style.display = "none";
  //   }
  //   tablinks = document.getElementsByClassName("tablinks");
  //   for (i = 0; i < tablinks.length; i++) {
  //     tablinks[i].className = tablinks[i].className.replace(" active", "");
  //   }
  //   document.getElementById(cityName).style.display = "block";
  //   evt.currentTarget.className += " active";
  //   document.getElementById("defaultOpen").click();
  // }

  // openTwoTab(evt: any, cityName: any) {
  //   var i, tabcontent, tablinks;
  //   tabcontent = document.getElementsByClassName("two_tabcontent");
  //   for (i = 0; i < tabcontent.length; i++) {
  //     tabcontent[i].style.display = "none";
  //   }
  //   tablinks = document.getElementsByClassName("two_tablinks");
  //   for (i = 0; i < tablinks.length; i++) {
  //     tablinks[i].className = tablinks[i].className.replace(" active", "");
  //   }
  //   document.getElementById(cityName).style.display = "block";
  //   evt.currentTarget.className += " active";


  // document.getElementById("twoDefault").click();
  // }

  // modalSucc : any;

  // openModelOTP() {
  //     // otp modal
  // let modalOtp = document.getElementById("otpModal") as HTMLElement;
  // let buttonOtp = document.getElementById("otpbutton") as HTMLElement;
  // let closeOtp = document.getElementById("optclose") as HTMLElement;
  // buttonOtp.onclick = function () {
  //   modalOtp.style.display = "flex";
  // };
  // closeOtp.onclick = function () {
  //   modalOtp.style.display = "none";
  // };

  // //   update successfully modal
  // //   make below "modalsucc" display flex when otp matches
  // this.modalSucc = document.getElementById("succmodal");
  // let closesucc = document.getElementById("succclose");
  // closesucc.onclick = function () {
  //   this.modalSucc.style.display = "none";
  // };

  // // two factor modal
  // let modalTwo = document.getElementById("secmodal");
  // let closeTwo = document.getElementById("twoClose");
  // let buttonTwo = document.getElementById("twoSave");
  // buttonTwo.onclick = function () {
  //   // modalTwo.style.display = "flex";
  //   modalTwo.style.display = "flex";
  // };
  // closeTwo.onclick = function () {
  //   modalTwo.style.display = "none";
  // };
  // }

  // let coll = document.getElementsByClassName("collapsible");
  // let i;

  // for (i = 0; i < coll.length; i++) {
  //   coll[i].addEventListener("click", function () {
  //     this.classList.toggle("active");
  //     var content = this.nextElementSibling;
  //     if (content.style.maxHeight) {
  //       content.style.maxHeight = null;
  //     } else {
  //       content.style.maxHeight = content.scrollHeight + "px";
  //     }
  //   });
  // }
}
