import { Component } from '@angular/core';
import { Message } from 'primeng/api';
import { ProfileService } from 'src/app/Services/profile.service';
import { MenuItem } from 'primeng/api/menuitem';
import { MessageService } from 'primeng/api';
import { TokenService } from 'src/app/Services/token.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-manage-user-profile',
  templateUrl: './manage-user-profile.component.html',
  styleUrls: ['./manage-user-profile.component.scss'],
  providers: [MessageService]
})
export class ManageUserProfileComponent {
  items: MenuItem[] = [];
  sectionId: number = 0;
  commonOptions: any[] = [];
  genderOptions: any[] = [];
  ingredient: any;
  messages1: Message[] = [];

  messages2: Message[] = [];
  showpopup:boolean=false;
  modal: any;
  kycStatus:any;
  kycText:any;
  UserKycStatus:any;

  constructor(private messageService: MessageService,
              private profile:ProfileService  ) {}

      baseUrl = environment.baseUrl;
      userdata:any = [];
      public error :boolean = false;
      isDisabled: boolean = false;
      

       profileForm={
        userId:'',
        userName:'',
        phoneNumber:'',
        email:'',
        secondaryEmail:'',
        country:'',
        companyName:'',
        comapanyLocation:'',
        taxRule:'',
        timeZone:'',
        link:'',
        companyLocation:'',
        kyc_status:'',
        kyc_text:'',
       }  
       currency:any 
       
       socialForm ={
         telegram:'',
         discord:'',
         facebook:'',
         instagram:''
       }

       kycForm ={
         firstName:'',
         lastName:'',
         phoneNumber:'',
         gender:'',
         dob:'',
         country:'',
         state:'',
         city:'',
         postalCode:'',
         address1:'',
         address2:'',
         idType:'',
         idNumber:'',
         id_exp:''
       }
       
  ngOnInit() {
    
      this.profile. profiledetails().subscribe(
        data => this.handleUserProfile(data),
        error => this.handleError(error)
      );


    this.modal = document.getElementById("myModal");
    this.genderOptions =[
      {name:'Male',code:'male'},
      {name:'Female',code:'female'},
      {name:'Non-Binary',code:'nonbinary'},
      {name:'Other',code:'other'},
    ];

    this.commonOptions = [
      { name: 'India', code: 'india' },
      { name: 'USA', code: 'usa' },
      { name: 'China', code: 'china' },
      { name: 'Russia', code: 'russia' },
      { name: 'Japan', code: 'japan' },
    ];
    this.items = [
      {
        label: 'User Profile',
        command: () => {
          this.setSection(0);
        },
      },
      {
        label: 'KYC',
        command: () => {
          this.setSection(1);
        },
      },
      {
        label: 'Currency Preferences',
        command: () => {
          this.setSection(2);
        },
      },
      {
        label: 'Social Media',
        command: () => {
          this.setSection(3);
        },
      },
    ];

    this.messages1 = [{ severity: 'success', summary: 'Success', detail: '' }];

    this.messages2 = [
      {
        severity: 'error',
        summary: 'Error',
        detail: 'Closable Message Content',
      },
    ];
  }


  kycUpdate(){
    console.log(this.kycForm);
    this.error =false;
    this.profile.kycUpdate(this.kycForm).subscribe(
      data => this.handleKycRes(data),
      error => this.handleError(error)
    );
  }

  handleKycRes(data:any){
    if(data.success){
      this.showpopup=true;
      this.error =false;
      console.log('true');

      setTimeout(()=>{
       this.showpopup=false
      },2000);
    }
    else{
      this.error = data.message;
    }
  }

  profileUpdate(){
      console.log(this.profileForm);
      this.profile.profileupdate(this.profileForm).subscribe(
        data => this.handleprofileUpdate(data),
        error => this.handleError(error)
      );
  }

  handleprofileUpdate(data:any){
     if(data.success){
       console.log('success',data);
     }
     else{
       this.error = data.message
     }
  }
     
  handleUserProfile(data:any){
     console.log(data)
     if(data.success){
      this.profileForm.userName         = data.result.userName ? data.result.userName : '';
      this.profileForm.userId           = data.result.userId  ? data.result.userId :'';
      this.profileForm.phoneNumber      = data.result.phonenumber ? data.result.phonenumber:'';
      this.profileForm.email            = data.result.email ? data.result.email:'';
      this.profileForm.secondaryEmail   = data.result.secondaryEmail? data.result.secondaryEmail:'';
      this.profileForm.country          = data.result.country ? data.result.country:'';
      this.profileForm.companyName      = data.result.companyName ? data.result.companyName:'';
      this.profileForm.taxRule          = data.result.taxRule ? data.result.taxRule:'';
      this.profileForm.timeZone         = data.result.timeZone ? data.result.timeZone:'';
      this.profileForm.link             = data.result.link? data.result.link:'';
      this.profileForm.companyLocation  = data.result.companyLocation? data.result.companyLocation:'';
      this.profileForm.kyc_status       = data.result.kyc_status;
      this.profileForm.kyc_text         = data.result.kyc_text? data.result.kyc_text:'';
    
     }
     else{
      this.error = data.message;
     }
     console.log('sdfghj',this.profileForm.kyc_status);
     const UserKycStatus = this.profileForm.kyc_status;
     if(this.UserKycStatus !== '0'){
      this.kycStatus = true;
      this.kycText =this.profileForm.kyc_text;
     }
  }

  getColorBasedOnStatus(): string {
    switch (this.UserKycStatus) {
      case 0:
        return '#ffffff'; // White
      case 1:
        return '#008000'; // Green
      case 2:
        return '#008000'; // Green (assuming the same as case 1)
      case 3:
        return '#ff0000'; // Red
      default:
        return '#ffffff'; // Default color (you can set a different color or handle other cases)
    }
  }
  

  Currency(){
    console.log(this.currency)
    this.profile.currency(this.currency).subscribe(
      (data)=>{
         if(data) {

         }
         else{
          //  this.error = data.message;
         }
       },
       (error)=>{
         console.log(error);
       }
     );
  }

  social(){
     console.log();
  }

  handleError(error:any){
    console.log(error);
  }

  copyToClipboard(el: any) {
    console.log(el);

    if (navigator.clipboard) {
      navigator.clipboard.writeText(el).then(
        () => {
          this.showSuccess();
        },
        (error) => {
          console.log(error);
          this.showError();
        }
      );
    } else {
      this.showInfo();
    }
  }

  showSuccess() {
    this.messageService.add({
      severity: 'success',
      summary: 'Success',
      detail: 'Copied to Clipboard',
    });
  }

  showInfo() {
    this.messageService.add({
      severity: 'info',
      summary: 'Info',
      detail: 'Browser do not support Clipboard API',
    });
  }

  showError() {
    this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Error While Copying Content' });
}

  setSection(sectionId: number) {
    this.sectionId = sectionId;
  }
  openModel() {
    this.modal.style.display = "block";
    console.log("Open Model");
  }
  closeModel() {
    this.modal.style.display = "none";
   }
}
